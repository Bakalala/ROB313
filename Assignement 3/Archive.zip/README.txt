Each Subsection of the assignment has it's own ipynb file.
Open the file and run it in order to get the Data
Variables are clear and can easily be changed, as the code is written to be easily modified for most cases.
